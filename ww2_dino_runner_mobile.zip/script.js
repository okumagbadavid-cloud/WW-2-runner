
const boy = document.getElementById("boy");
const obstacle = document.getElementById("obstacle");
const soldier = document.getElementById("soldier");
let isJumping = false;
let gameOver = false;

document.addEventListener("touchstart", () => {
    if (!isJumping && !gameOver) {
        jump();
    }
});

function jump() {
    isJumping = true;
    let up = 0;
    const jumpInterval = setInterval(() => {
        if (up >= 100) {
            clearInterval(jumpInterval);
            const fallInterval = setInterval(() => {
                if (up <= 0) {
                    clearInterval(fallInterval);
                    isJumping = false;
                } else {
                    up -= 5;
                    boy.style.bottom = 10 + up + "%";
                }
            }, 20);
        } else {
            up += 5;
            boy.style.bottom = 10 + up + "%";
        }
    }, 20);
}

function moveObstacle() {
    if (gameOver) return;

    let position = 100;
    obstacle.style.right = "-60px";
    obstacle.style.display = "block";
    
    const obstacleInterval = setInterval(() => {
        if (position < -10) {
            position = 100;
        } else {
            position -= 1.5;
        }
        obstacle.style.right = position + "%";

        const boyLeft = boy.getBoundingClientRect().left;
        const boyRight = boyLeft + boy.offsetWidth;
        const obstacleBox = obstacle.getBoundingClientRect();

        if (
            boyRight > obstacleBox.left &&
            boyLeft < obstacleBox.right &&
            boy.getBoundingClientRect().bottom > obstacleBox.top
        ) {
            clearInterval(obstacleInterval);
            endGame();
        }
    }, 10);
}

function endGame() {
    gameOver = true;
    document.getElementById("message").innerText = "Пойман! Обнови страницу, чтобы начать заново.";
    soldier.style.left = "10%";
}

setInterval(moveObstacle, 2000);
